export interface cuenta{
    name?: string,
    email: string,
    token?: any,
    avatar?: string,
    password?:string;
    
}