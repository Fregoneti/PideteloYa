export interface Lugar{
    id?:any,
    name: string,
    photo?: any,
    n_phone?: string,
    adress?: string,
    latitude?:any,
    star?:any,
    longitude?:any,
    comentarios?:[],

}