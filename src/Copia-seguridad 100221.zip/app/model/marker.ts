interface Marker {
  position: {
    lat: number,
    lng: number,
  };
  title: string;
}